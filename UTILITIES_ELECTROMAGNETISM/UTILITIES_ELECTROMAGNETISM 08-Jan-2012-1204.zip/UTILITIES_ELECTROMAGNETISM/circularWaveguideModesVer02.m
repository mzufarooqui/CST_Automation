close all;clear all;clc
a         = 1.3; % Radius of the circular waveguide
m         = 1;
n         = 1;
load chiPrimValue
load chiValue
velLight  = 300;  % Velocity of Light in mm/ns
eps_m     = 1 * ( m == 0 ) + 2 * ( m > 0 );
eps_n     = 1 * ( n == 0 ) + 2 * ( n > 0 );

% new line
x       = linspace(-a,a,12);
y       = linspace(-a,a,10);
[X,Y]=meshgrid(x,y);
[phi,rho]=cart2pol(X,Y);



%-- Chi, Chi', Jm and Jm'
chi_m_n   = chiValue(m+1,n);
chiPr_m_n = chiPrimValue(m+1,n);
J         = @(m,in)( besselj( m , in ) );
J_Prime   = @(m,in)( (J( m-1 , in ) - J( m+1 , in ))/2  );


%-- For TE Modes
kt_TE = chiPr_m_n / a;
fc_TE = kt_TE / ( 2 * pi) * velLight;

psi_m_n  =   sqrt( eps_m / pi ) * ( chiPr_m_n /(sqrt(chiPr_m_n)^2 - m^2))            * J(m,chiPr_m_n*rho/a) / ( a * J(m,chiPr_m_n) )       .* cos( m * phi );

eRho_TE  =   sqrt( eps_m / pi ) * ( J(m,chiPr_m_n*rho/a) /(sqrt(chiPr_m_n)^2 - m^2)) * m ./ ( rho * J(m,chiPr_m_n) )                        .* sin( m * phi );
ePhi_TE  =   sqrt( eps_m / pi ) * ( chiPr_m_n /(sqrt(chiPr_m_n)^2 - m^2))            * J_Prime(m,chiPr_m_n*rho/a) / ( a * J(m,chiPr_m_n) ) .* cos( m * phi );

%-- Transformation from Cylindrical to Cartesian
[x y ]             = pol2cart(phi,rho);

% new line
% Ex=eRho_TE.*cos(phi)-ePhi_TE.*sin(phi);
% Ey=eRho_TE.*sin(phi)+ePhi_TE.*cos(phi);

Ex=eRho_TE.*cos(phi)-ePhi_TE.*sin(phi);
Ey=eRho_TE.*sin(phi)+ePhi_TE.*cos(phi);
Ex(rho>a)=NaN;
Ey(rho>a)=NaN;

figure
quiver(x,y,Ex,Ey,'r');
grid on
hold on;axis equal
% legend('E','H');
title(['TE_{' num2str(m) num2str(n) '} Mode']);
xlabel('x[mm]');ylabel('y[mm]');
set(gcf,'Units','Normalized','Position',[0 0 1 1]);